import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'colors.dart';

class InkText {
  static TextStyle bodyStrong() =>
      GoogleFonts.montserrat(fontSize: 18, color: InkColors.neonTeal, fontWeight: FontWeight.w700);
}
