import 'package:flutter/material.dart';

class InkColors {
  static const Color bg = Color(0xFF0B0B0B);
  static const Color neonTeal = Color(0xFF00FFD1);
  static const Color neonMagenta = Color(0xFFFF2DD1);
  static const Color neonYellow = Color(0xFFFFF500);
}
