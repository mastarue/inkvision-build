import 'package:flutter/material.dart';
import 'colors.dart';
import 'typography.dart';

class InkButton extends StatelessWidget {
  final String label;
  final VoidCallback? onPressed;
  const InkButton({super.key, required this.label, this.onPressed});
  @override
  Widget build(BuildContext context) {
    return ElevatedButton(
      onPressed: onPressed,
      style: ElevatedButton.styleFrom(
        backgroundColor: InkColors.neonTeal,
        foregroundColor: Colors.black,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
      ),
      child: Text(label, style: InkText.bodyStrong()),
    );
  }
}

ThemeData buildInkTheme() {
  return ThemeData.dark().copyWith(
    scaffoldBackgroundColor: InkColors.bg,
    colorScheme: const ColorScheme.dark().copyWith(
      primary: InkColors.neonTeal,
      secondary: InkColors.neonMagenta,
    ),
    appBarTheme: const AppBarTheme(
      backgroundColor: Colors.transparent,
      elevation: 0,
    ),
  );
}
